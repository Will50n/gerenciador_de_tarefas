import React from "react";
import { TaskContext } from "./Reducer";
import NovaTarefa from "../components/NovaTarefa";
import ListaDeTarefas from "../components/ListaDeTarefas";
import FiltroTarefas from "../components/FiltroTarefas";

function Home() {
  return (
    <TaskContext>
      <div>
        <h1>Gerenciador de Tarefas</h1>
        <NovaTarefa />
        <FiltroTarefas />
        <ListaDeTarefas />
      </div>
    </TaskContext>
  );
}

export default Home;
