import React, { useContext } from "react";
// import { TaskContext as Global } from "../context/TaskContext";
import { TaskContext } from "../pages/Reducer";


function FiltroTarefas() {
  const { state, dispatch } = useContext(TaskContext);

  return (
    <div>
      <button
        onClick={() => dispatch({ type: "SET_FILTER", payload: "all" })}
        disabled={state.filter === "tudo"}
      >
        Todas
      </button>
      <button
        onClick={() => dispatch({ type: "SET_FILTER", payload: "done" })}
        disabled={state.filter === "feito"}
      >
        Concluídas
      </button>
      <button
        onClick={() => dispatch({ type: "SET_FILTER", payload: "pending" })}
        disabled={state.filter === "pendente"}
      >
        Pendentes
      </button>
    </div>
  );
}

export default FiltroTarefas;
