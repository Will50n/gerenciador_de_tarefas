import React, { useContext } from "react";
import { TaskContext } from "../pages/Reducer";
import Tarefa from "./Tarefa";


function ListaDeTarefas() {
  const { state } = useContext(TaskContext);
  const { tasks, filter } = state;

  const filteredTasks = tasks.filter((task) => {
    if (filter === "feito") return task.done;
    if (filter === "pendente") return !task.done;
    return true; // tudo
  });

  return (
    <ul>
      {filteredTasks.map((task) => (
        <Tarefa key={task.id} task={task} />
      ))}
    </ul>
  );
}

export default ListaDeTarefas;
